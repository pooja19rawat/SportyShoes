package com.SportyShoes.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SportyShoes.model.PurchaseItem;
import com.SportyShoes.model.PurchaseOrder;
import com.SportyShoes.repository.PurchaseOrderRepository;

@Service(value="purchaseOrderService")
public class PurchaseOrderServiceImpl implements PurchaseOrderService{

	@Autowired
	PurchaseOrderRepository purchaseOrderRepository;
	
	@Override
	public PurchaseOrder getPurchaseById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PurchaseOrder> getAllPurchaseOrder() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PurchaseOrder> getAllPurchaseOrderbyUserId(Long userid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PurchaseOrder savePurchaseOrder(PurchaseOrder purchaseorder) {
		// TODO Auto-generated method stub
		return purchaseOrderRepository.save(purchaseorder);
	}


	}

