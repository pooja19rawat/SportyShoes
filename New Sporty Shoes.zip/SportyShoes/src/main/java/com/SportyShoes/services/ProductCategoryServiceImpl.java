package com.SportyShoes.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SportyShoes.model.ProductCategory;
import com.SportyShoes.repository.ProductCategoryRepository;

@Service(value="ProductCategoryService")
public class ProductCategoryServiceImpl implements ProductCategoryService {

	
	@Autowired
	ProductCategoryRepository productCategoryRepository;
	@Override
	public ProductCategory getCategorybyId(Long id) {
		// TODO Auto-generated method stub
		return productCategoryRepository.findById(id).get();
	}

	@Override
	public void updateCategory(ProductCategory category) {
		// TODO Auto-generated method stub
		productCategoryRepository.save(category);
	}

	@Override
	public ProductCategory saveCategory(ProductCategory category) {
		// TODO Auto-generated method stub
		return productCategoryRepository.save(category);
	}

	@Override
	public void deleteCategory(Long id) {
		// TODO Auto-generated method stub
		productCategoryRepository.deleteById(id);
	}

	@Override
	public List<ProductCategory> fetchProductCategoryList() {
		// TODO Auto-generated method stub
		return productCategoryRepository.findAll();
	}

}
