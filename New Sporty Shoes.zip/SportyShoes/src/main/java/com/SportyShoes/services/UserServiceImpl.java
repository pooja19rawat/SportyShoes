package com.SportyShoes.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SportyShoes.model.User;
import com.SportyShoes.repository.UserRepository;

@Service(value="userService")
public class UserServiceImpl implements UserService{

	@Autowired
	UserRepository userRepository;
	
	@Override
	public List<User> fetchUserList() {
		// TODO Auto-generated method stub
		System.out.println(userRepository.findAll().toString());
		return userRepository.findAll();
	}

	@Override
	public User saveUser(User user) {
		// TODO Auto-generated method stub
		System.out.println("user saved");
		return userRepository.save(user);
	}

	@Override
	public void deleteByEmialId(String emailId) {
		// TODO Auto-generated method stub
		userRepository.deleteById(emailId);
	}

	@Override
	public User getUser(String emailId) {
		// TODO Auto-generated method stub
		return userRepository.findById(emailId).get();
	}

	@Override
	public void updateUser(User user) {
		// TODO Auto-generated method stub
	if(userRepository.findById(user.getEmailId()).get()!=null) 
	{
		userRepository.save(user);
		System.out.println(user.getEmailId()+user.getFirstname());
	}
	}

	@Override
	public User getUser(String emailId, String password) {
		// TODO Auto-generated method stub
		return null;
	}

}
