package com.SportyShoes.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SportyShoes.model.PurchaseItem;
import com.SportyShoes.model.PurchaseOrder;
import com.SportyShoes.model.User;
import com.SportyShoes.repository.PurchaseItemRepository;

@Service(value="purchaseItemService")
public class PurchaseItemServiceImpl implements PurchaseItemService{

	@Autowired
	PurchaseItemRepository purchaseItemRepository;
	
	@Override
	public PurchaseItem getPurchaseItemById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PurchaseItem> getAllItemByPurchaseOrder(PurchaseOrder order) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PurchaseItem> getAllItemsByUserId(User userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PurchaseItem savePurchaseItem(PurchaseItem purchaseItem) {
		// TODO Auto-generated method stub
		return purchaseItemRepository.save(purchaseItem);
	}

	@Override
	public List<PurchaseItem> getAllPurchaseItemList() {
		// TODO Auto-generated method stub
		return purchaseItemRepository.findAll();
	}

}
