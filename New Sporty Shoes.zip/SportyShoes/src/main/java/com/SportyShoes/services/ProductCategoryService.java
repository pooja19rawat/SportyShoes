package com.SportyShoes.services;

import java.util.List;

import com.SportyShoes.model.ProductCategory;

public interface ProductCategoryService {

	public ProductCategory getCategorybyId(Long id);
	public void updateCategory(ProductCategory category);
	public ProductCategory saveCategory(ProductCategory category);
	public void deleteCategory(Long id);
	public List<ProductCategory> fetchProductCategoryList();
	

}
