package com.SportyShoes.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SportyShoes.model.Product;
import com.SportyShoes.model.ProductCategory;
import com.SportyShoes.repository.ProductRepository;


@Service(value="productService")
public class ProductServiceImpl implements ProductService{

	@Autowired
	private ProductRepository productRepository;
	
	@Override
	public Product getProductById(Long productCode) {
		// TODO Auto-generated method stub
		return productRepository.findById(productCode).get();
	}

	@Override
	public Product getProductByProductCategory(ProductCategory productCategory) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateProduct(Product product) {
		// TODO Auto-generated method stub
		if (productRepository.findById(product.getProductCode()).get()!=null) {
			productRepository.save(product);
		}
	}

	@Override
	public Product saveProduct(Product product) {
		// TODO Auto-generated method stub
		return productRepository.save(null);
	}

	@Override
	public void deleteProduct(Long productCode) {
		// TODO Auto-generated method stub
		productRepository.deleteById(productCode);
	}

	@Override
	public List<Product> getAllProduct() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
	}

}
