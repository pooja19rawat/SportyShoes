package com.SportyShoes.services;

import java.util.List;

import com.SportyShoes.model.PurchaseOrder;

public interface PurchaseOrderService {

	public PurchaseOrder getPurchaseById(Long id);
	public List<PurchaseOrder> getAllPurchaseOrder();
	public List<PurchaseOrder> getAllPurchaseOrderbyUserId(Long userid);
	public PurchaseOrder savePurchaseOrder(PurchaseOrder purchaseorder);
	
}
