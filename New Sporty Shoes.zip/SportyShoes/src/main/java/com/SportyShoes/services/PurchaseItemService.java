package com.SportyShoes.services;

import java.util.List;

import com.SportyShoes.model.PurchaseItem;
import com.SportyShoes.model.PurchaseOrder;
import com.SportyShoes.model.User;

public interface PurchaseItemService {

	public PurchaseItem getPurchaseItemById(Long id);
	public List<PurchaseItem> getAllItemByPurchaseOrder(PurchaseOrder order);
	public List<PurchaseItem> getAllItemsByUserId(User userId);
	public PurchaseItem savePurchaseItem(PurchaseItem purchaseItem);
	public List<PurchaseItem> getAllPurchaseItemList();
	
}
