package com.SportyShoes.config;

public class HibConfig {

}
