package com.SportyShoes.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SportyShoes.model.PurchaseItem;

public interface PurchaseItemRepository extends JpaRepository<PurchaseItem,Long>{

}
