package com.SportyShoes.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.SportyShoes.model.User;
import com.SportyShoes.services.UserService;

@RestController
public class UserController {

	
	private UserService userService;
	
	@GetMapping("/users")
	public List<User> getAllUsers()
	{
		return userService.fetchUserList();
	}
}
