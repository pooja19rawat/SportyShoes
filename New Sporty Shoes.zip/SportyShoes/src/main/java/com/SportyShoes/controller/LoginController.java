package com.SportyShoes.controller;

import org.springframework.stereotype.Controller;

@Controller
public class LoginController {

}
