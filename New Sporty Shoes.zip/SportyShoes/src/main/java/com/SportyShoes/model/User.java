package com.SportyShoes.model;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorColumn;
import jakarta.persistence.DiscriminatorType;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.Table;

@Entity
@Table(name="USER")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(discriminatorType = DiscriminatorType.STRING, name = "User_Role")
@DiscriminatorValue("Customer")

public class User {

	@Id
	private String emailId;
	
	@Column(length=20)
	private String password;
	
	@Column
	private String firstname;
	
	@Column
	private String lastname;
	
	@Column
	private String country;
	
	@Column
	private String gender;
	
	@Column
	private Date dateofBirth;

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User(String emailId, String password, String firstname, String lastname, String country, String gender,
			Date dateofBirth) {
		super();
		this.emailId = emailId;
		this.password = password;
		this.firstname = firstname;
		this.lastname = lastname;
		this.country = country;
		this.gender = gender;
		this.dateofBirth = dateofBirth;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getDateofBirth() {
		return dateofBirth;
	}

	public void setDateofBirth(Date dateofBirth) {
		this.dateofBirth = dateofBirth;
	}

	@Override
	public String toString() {
		return "User [emailId=" + emailId + ", password=" + password + ", firstname=" + firstname + ", lastname="
				+ lastname + ", country=" + country + ", gender=" + gender + ", dateofBirth=" + dateofBirth + "]";
	}
	
}
