package com.SportyShoes.model;

import java.math.BigDecimal;

public class CartItem {

	private Long productid;
	private String name;
	private BigDecimal rate; // per item
	private int quantity;
	private BigDecimal price;
	private String image_url;
	public CartItem() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CartItem(Long productid, String name, BigDecimal rate, int quantity, BigDecimal price, String image_url) {
		super();
		this.productid = productid;
		this.name = name;
		this.rate = rate;
		this.quantity = quantity;
		this.price = price;
		this.image_url = image_url;
	}
	public Long getProductid() {
		return productid;
	}
	public void setProductid(Long productid) {
		this.productid = productid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public BigDecimal getRate() {
		return rate;
	}
	public void setRate(BigDecimal rate) {
		this.rate = rate;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	public String getImage_url() {
		return image_url;
	}
	public void setImage_url(String image_url) {
		this.image_url = image_url;
	}
	@Override
	public String toString() {
		return "CartItem [productid=" + productid + ", name=" + name + ", rate=" + rate + ", quantity=" + quantity
				+ ", price=" + price + ", image_url=" + image_url + "]";
	}
	
	
}
