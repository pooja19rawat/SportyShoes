package com.SportyShoes.model;

import java.math.BigDecimal;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class PurchaseItem {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long ID;
	
	@ManyToOne
	@JoinColumn(name="purchaseOrder_fk")
	private PurchaseOrder purchaseOrder;
	
	@ManyToOne
	@JoinColumn(name="product_fk")
	private Product product;
	
	@ManyToOne
	@JoinColumn(name="user_fk")
	private User user;
	
	private BigDecimal rate;
	
	private int size;
	
	private BigDecimal price;

	public PurchaseItem() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PurchaseItem(Long iD, PurchaseOrder purchaseOrder, Product product, User user, BigDecimal rate, int size,
			BigDecimal price) {
		super();
		ID = iD;
		this.purchaseOrder = purchaseOrder;
		this.product = product;
		this.user = user;
		this.rate = rate;
		this.size = size;
		this.price = price;
	}

	public Long getID() {
		return ID;
	}

	public void setID(Long iD) {
		ID = iD;
	}

	public PurchaseOrder getPurchaseOrder() {
		return purchaseOrder;
	}

	public void setPurchaseOrder(PurchaseOrder purchaseOrder) {
		this.purchaseOrder = purchaseOrder;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public BigDecimal getRate() {
		return rate;
	}

	public void setRate(BigDecimal rate) {
		this.rate = rate;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "PurchaseItem [ID=" + ID + ", purchaseOrder=" + purchaseOrder + ", product=" + product + ", user=" + user
				+ ", rate=" + rate + ", size=" + size + ", price=" + price + "]";
	}
	
}
